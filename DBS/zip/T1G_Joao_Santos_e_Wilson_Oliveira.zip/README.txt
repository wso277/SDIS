Não são precisas configurações especiais para compilar o projeto. As configurações de rede devem ser fornecidas ao programa na primeira execução, seleccionando a 1ª opção do primeiro menu. Nas próximas utilizações é possivel carregar as configurações anteriores através da 2ª opcão deste menu.
O programa implementa as funcionalidades pedidas pelos protocolos e foi testado com vários computadores, em sistema operativo linux e windows.
Nenhum melhoramento de protocolo foi implementado.

Turma 1 - João Santos e Wilson Oliveira 